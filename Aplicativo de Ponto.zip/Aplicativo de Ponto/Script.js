class SistemaPonto {
  constructor() {
    this.chave = "pontos";
    this.lista = document.getElementById("lista");
    this.ultimaBatidaEl = document.getElementById("ultimaBatida");

    this.iniciarRelogio();
    this.atualizarTela();
  }

  pegarDados() {
    return JSON.parse(localStorage.getItem(this.chave)) || [];
  }

  salvarDados(dados) {
    localStorage.setItem(this.chave, JSON.stringify(dados));
  }

  registrar(tipo) {
    const agora = new Date();

    const registro = {
      data: agora.toLocaleDateString(),
      hora: agora.toLocaleTimeString(),
      tipo: tipo
    };

    const dados = this.pegarDados();
    dados.push(registro);
    this.salvarDados(dados);

    this.atualizarTela();
    alert(`${tipo} registrada com sucesso!`);
  }

  atualizarTela() {
    const dados = this.pegarDados();
    this.lista.innerHTML = "";

    dados.forEach(item => {
      const li = document.createElement("li");
      li.textContent = `${item.data} - ${item.hora} - ${item.tipo}`;
      this.lista.appendChild(li);
    });

    this.atualizarUltimaBatida(dados);
  }

  atualizarUltimaBatida(dados) {
    if (dados.length === 0) {
      this.ultimaBatidaEl.textContent = "N/A";
      return;
    }

    const ultima = dados[dados.length - 1];
    this.ultimaBatidaEl.textContent =
      `${ultima.data} às ${ultima.hora} (${ultima.tipo})`;
  }

  iniciarRelogio() {
    const horaEl = document.getElementById("hora");
    const dataEl = document.getElementById("data");

    const atualizar = () => {
      const agora = new Date();

      horaEl.textContent = agora.toLocaleTimeString();
      dataEl.textContent = agora.toLocaleDateString("pt-BR", {
        weekday: "long",
        day: "2-digit",
        month: "long",
        year: "numeric"
      });
    };

    atualizar();
    setInterval(atualizar, 1000);
  }
}

const app = new SistemaPonto();

function registrarPonto(tipo) {
  app.registrar(tipo);
}