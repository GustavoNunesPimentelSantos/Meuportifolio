//package exercicio9;
//Ex9.
import java.util.Scanner;

public class Exercicio9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Insira a string: ");
        String str = scanner.nextLine().toLowerCase();
        
        int contadorConsoantes = 0;
        for (char c : str.toCharArray()) {
            if (Character.isLetter(c) && "aeiou".indexOf(c) == -1) {
                contadorConsoantes++;
            }
        }
        
        System.out.println("O valor de consoantes é: " + contadorConsoantes);
    }
}