//package exercicio14;
//Ex14;
import java.util.Scanner;

public class Exercicio14 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Insira o primeiro número:");
        double num1 = scanner.nextDouble();

        System.out.println("Insira o segundo número:");
        double num2 = scanner.nextDouble();

        System.out.println("Escolha a operação: (+, -, *, /)");
        char operacao = scanner.next().charAt(0);

        double resultado;

        switch (operacao) {
            case '+':
            resultado = num1 + num2;
            System.out.println("Resultado da adição: " + resultado);
            break;
            case '-':
            resultado = num1 - num2;
            System.out.println("Resultado da subtração: " + resultado);
            break;
            case '*':
            resultado = num1 * num2; 
            System.out.println("Resultado da multiplicação: " + resultado);
            break;
            case '/':
                if (num2 != 0) {
                    resultado = num1 / num2;
                    System.out.println("Resultado da divisão: " + resultado);
                } else {
                    System.out.println("Erro: Divisão pelo zero não é permitida.");
                }
                break;
            default:
                System.out.println("Operação inválida.");
                break;
        }

        scanner.close();
    }
}