//package exercicio8;
//Ex8;
import java.util.Scanner;

public class Exercicio8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Insira uma palavra: ");
        String str = scanner.nextLine().toLowerCase();
        
    //Aqui eu conto o valor de vogais inseridas pelo usuario.
    int contadorVogais = 0;
    for (char c : str.toCharArray()) {
    if ("aeiou".indexOf(c) != -1) {
                contadorVogais++;
            }
}
        System.out.println("O valor de vogais é: " + contadorVogais);
    }}