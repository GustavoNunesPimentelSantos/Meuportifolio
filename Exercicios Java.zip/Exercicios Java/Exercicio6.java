//package exercicio6
//Ex6;
import java.util.Scanner;

public class Exercicio6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Insira um número: ");
        int numero = scanner.nextInt();
        
        if (numero <= 1) {
            System.out.println(numero + "esse valor não é um número primo.");
            return;
        }
        //As proximas linhas de codigo verificam se o resto da divisão é 0, se nao for, é um numero primo.
        boolean isPrimo = true;
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                isPrimo = false;
                break;
            }
        }
        //Isso é a estrutura condicional que verifica se o numero é primo ou não, respeitando as instruções acima.
        if (isPrimo) {
            System.out.println(numero + " é um número primo.");
        } else {
            System.out.println(numero + " não é um número primo.");
        }
    }
}
