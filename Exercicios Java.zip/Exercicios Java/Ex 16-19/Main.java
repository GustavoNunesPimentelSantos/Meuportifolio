//package main;
//Ex19;
public class Main {
    public static void main(String[] args) {
        Pessoa pessoa = new Pessoa("Cristian", 39);
        Aluno aluno = new Aluno("Joana", 24, "12345", "Engenharia");
        Funcionario funcionario = new Funcionario("Marcos", 42, 5000.0, "Gerente");

        System.out.println("Informações da Pessoa:");
        pessoa.exibirInformacoes();
        System.out.println("\nInformações do Aluno:");
        aluno.exibirInformacoes();
        System.out.println("\nInformações do Funcionário:");
        funcionario.exibirInformacoes();
    }
}