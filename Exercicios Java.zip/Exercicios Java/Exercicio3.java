//Ex3
public class Exercicio3 {
    public static void main(String[] args) {
        //Aqui eu abro um intervalo em que o valor inicial é 25, e o final 175
        int soma = 0; 
        int inicio = 25; 
        int fim = 175; 

        // Loop
        for (int i = inicio; i <= fim; i++) {
            soma += i; 
        }

        System.out.println("A soma dos valores de " + inicio + " a " + fim + " é: " + soma);
    }}