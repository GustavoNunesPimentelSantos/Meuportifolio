//package exercicio5
//Ex5
import java.util.Scanner;

public class Exercicio5 {
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Insira um número: ");
    int numero = scanner.nextInt();
        
    long fatorial = 1;
    for (int i = 1; i <= numero; i++) { //Essa linha é responsavel por pegar o numero fornecido, e multiplicar pelo restante das vezes. ex: 5x4x3x2x1=120
    fatorial *= i;
    }
        
        System.out.println("A fatorial de" + numero + "é" + fatorial);
}
}