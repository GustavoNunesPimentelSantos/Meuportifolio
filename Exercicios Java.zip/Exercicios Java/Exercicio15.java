//package exercicio15;
//Ex15;
import java.util.Scanner;

public class Exercicio15 {
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in); 
        
    //Limites
    System.out.println("Insira o limite inicial:");
    int limiteInicial = scanner.nextInt();

    System.out.println("Insira o limite final:");
    int limiteFinal = scanner.nextInt();

        if (limiteInicial > limiteFinal) {
            System.out.println("O limite inicial deve ser menor ou igual ao limite final.");
        } else {
            System.out.println("Os números  pares entre " + limiteInicial + " e " + limiteFinal + ":");
            for (int i = limiteInicial; i <= limiteFinal; i++) {
                if (i % 2 == 0) {
                    System.out.println(i);
                }
            }
        }

        scanner.close();
    }
};