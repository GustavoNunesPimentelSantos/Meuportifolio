//package exercicio13;
//Ex13;
import java.util.Scanner;

public class Exercicio13 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
    while (true) {
    System.out.println("Escolha a conversão desejada:");
    System.out.println("1) Celsius para Fahrenheit");
    System.out.println("2) Fahrenheit para Celsius");
    System.out.println("3) Sair");
    System.out.print("Insira o número da opção: ");
            
            int opcao = scanner.nextInt();
            
            if (opcao == 3) {
                System.out.println("Terminando...");
                break;
            }
            
            double temperatura;
            
            switch (opcao) {
                case 1:
                System.out.print("Insira a temperatura em Celsius: ");
                temperatura = scanner.nextDouble();
                double fahrenheit = celsiusParaFahrenheit(temperatura);
                System.out.printf("%.2f Celsius é igual a %.2f Fahrenheit\n", temperatura, fahrenheit);
                break;
                
                case 2:
                System.out.print("Insira a temperatura em Fahrenheit: ");
                temperatura = scanner.nextDouble();
                double celsius = fahrenheitParaCelsius(temperatura);
                System.out.printf("%.2f Fahrenheit é igual a %.2f Celsius\n", temperatura, celsius);
                break;
                
                default:
                System.out.println("Opção inválida.");
                break;
            }
        }
        
        scanner.close();
    }

    public static double celsiusParaFahrenheit(double celsius) {
        return (celsius * 9/5) + 32;
    }

    public static double fahrenheitParaCelsius(double fahrenheit) {
        return (fahrenheit - 32) * 5/9;
    }
}