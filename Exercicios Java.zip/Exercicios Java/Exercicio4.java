//package exercicio4
//Ex4
import java.util.Scanner;

public class Exercicio4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Pede ao usuario um valor inteiro para ver a tabuada
        System.out.print("Insira um número para ver a tabuada: ");
        int numero = scanner.nextInt();

        // Mostra a tabuada
        System.out.println("Tabuada do número " + numero + ":");
        for (int i = 1; i <= 10; i++) {
            int resultado = numero * i; //o resultado é o numero multiplicado por 1-10.
            System.out.println(numero + " x " + i + " = " + resultado);
        }
        scanner.close();
    }
}