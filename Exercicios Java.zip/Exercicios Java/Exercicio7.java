//package exercicio7;
//Ex7
import java.util.Scanner;

public class Exercicio7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Insira a palavra: ");
        String str = scanner.nextLine();
        
        String inverso = new StringBuilder(str).reverse().toString();
        
        System.out.println("A palavra ou string invertida é: " + inverso);
    }
}