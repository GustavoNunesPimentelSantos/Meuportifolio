//package exercicio11;
//Ex11;
import java.util.Scanner;

public class Exercicio11 {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        int quantidadeDeNumeros = 10;
        double soma = 0;

        System.out.println("Insira 10 valores");

        for (int i = 0; i < quantidadeDeNumeros; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            double numero = scanner.nextDouble();
            soma += numero;
        }

        double media = soma / quantidadeDeNumeros;
        System.out.println("A média dos valores é: " + media);


        scanner.close();
    }
}