//package exercicio2; eu utilizo esse pacote caso eu tenho uma pasta para outros exercicios.
//O objetivo desse algoritmo é ler 5 nums e exibir o maior deles.
//Ex2
import java.util.Scanner;

public class Exercicio2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int maior = Integer.MIN_VALUE; 

        for (int i = 1; i <= 5; i++) {
            System.out.print("Insira o número " + i + ": ");
            int numero = scanner.nextInt();
            if (numero > maior) {
                maior = numero;
            }
        }
        System.out.println("O maior dos números é: " + maior);
    }
}