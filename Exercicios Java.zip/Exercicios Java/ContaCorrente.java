//package contacorrente
//Ex21;
import java.util.Scanner;

public class ContaCorrente {
    private double saldo;

    public ContaCorrente(double saldoInicial) {
        this.saldo = saldoInicial;
    }

    public void deposito(double valor) {
        if (valor > 0) {
            saldo += valor;
            System.out.println("Depósito de" + valor + " realizado. Saldo atual:" + saldo);
        } else {
            System.out.println("O valor do depósito deve ser positivo.");
        }
    }

    public void saque(double valor) {
        if (valor > 0) {
            if (valor <= saldo) {
                saldo -= valor;
                System.out.println("Saque de " + valor + " realizado. Saldo atual:" + saldo);
            } else {
                System.out.println("Saldo insuficiente para saque.");
            }
        } else {
            System.out.println("O valor do saque deve ser positivo.");
        }
    }

    public void transferencia(double valor) {
        if (valor > 0) {
            if (valor <= saldo) {
                saldo -= valor;
                System.out.println("Transferência de " + valor + " realizada. Saldo atual:" + saldo);
            } else {
                System.out.println("Saldo insuficiente para transferência.");
            }
        } else {
            System.out.println("O valor da transferência deve ser positivo.");
        }
    }

    public double getSaldo() {
        return saldo;
    }

    // Método main para testar a classe
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Criar instância de ContaCorrente
        System.out.print("Insira o saldo inicial da conta:");
        double saldoInicial = scanner.nextDouble();
        ContaCorrente conta = new ContaCorrente(saldoInicial);

        // Exibir saldo inicial
        System.out.println("Saldo inicial da conta:" + conta.getSaldo());

        System.out.print("Insira o valor para depósito:");
        double valorDeposito = scanner.nextDouble();
        conta.deposito(valorDeposito);

        System.out.print("Insira o valor para saque:");
        double valorSaque = scanner.nextDouble();
        conta.saque(valorSaque);

        System.out.print("Insira o valor para transferência:");
        double valorTransferencia = scanner.nextDouble();
        conta.transferencia(valorTransferencia);

        // Exibir saldo final
        System.out.println("Saldo final da conta:" + conta.getSaldo());

        // Fechar o scanner
        scanner.close();
    }
}