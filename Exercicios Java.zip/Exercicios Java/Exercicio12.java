//package exercicio12;
//Ex12;
import java.util.Scanner;

public class Exercicio12 {
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
        
    System.out.print("Insira o número de termos da sequência de Fibonacci que deseja exibir: ");
    int N = scanner.nextInt();
        
        if (N <= 0) {
            System.out.println("O número de termos deverá ser positivo.");
        } else {
            System.out.println("A Sequência de Fibonacci é:");
            for (int i = 0; i < N; i++) {
                System.out.print(fibonacci(i) + " ");
            }
        }
        
        scanner.close();
    }

    // Aqui eu calculo o n valor da sequencia de fibonacci.
    public static int fibonacci(int n) {
        if (n == 0) {
            return 0;
        } else if (n == 1) {
            return 1;
        } else {
            return fibonacci(n - 1) + fibonacci(n - 2);
        }
    }
}