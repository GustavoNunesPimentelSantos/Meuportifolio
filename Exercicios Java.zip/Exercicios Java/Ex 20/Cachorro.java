//package animal;
//Ex20A
public class Cachorro implements Animal {
    @Override
    public void fazerSom() {
        System.out.println("Latido");
    }

    @Override
    public void mover() {
        System.out.println("Corre");
    }
}