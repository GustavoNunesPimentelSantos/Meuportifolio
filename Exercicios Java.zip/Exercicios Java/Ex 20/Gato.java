//package animal;
//Ex20B;
public class Gato implements Animal {
    @Override
    public void fazerSom() {
        System.out.println("Miau");
    }

    @Override
    public void mover() {
        System.out.println("Anda Ligeiramente");
    }
}