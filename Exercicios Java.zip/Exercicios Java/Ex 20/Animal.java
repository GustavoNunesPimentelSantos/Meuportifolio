//package Animal;
//Ex20;
public interface Animal {
    void fazerSom();
    void mover();
}