//package main;
//Ex25;
public class Main {
    public static void main(String[] args) {
    // Instanciar autores
    Autor autor1 = new Autor("Machado de Assis", "24525525253");
    Autor autor2 = new Autor("J.R.R Tolkien", "91290932912");
    Autor autor3 = new Autor("Aluísio de Azevedo", "94211221423");

    // Instanciar editoras
    Editora editora1 = new Editora("Editora do RJ", "Lobo de Assis", "183e2438000196");
    Editora editora2 = new Editora("Editor E", "Rua 2", "13232438000196");
    Editora editora3 = new Editora("Editora do RJ", "Rua 3", "12345678000197");

    // Aqui instancio os livros
    Livro livro1 = new Livro("Memorias postumas de bras cubas", 1881, autor1, editora1);
    Livro livro2 = new Livro("O Hobbit", 1937, autor2, editora2);
    Livro livro3 = new Livro("O Cortiço", 1900, autor3, editora3);

    // Aqui eu exibo as informações dos livros
    System.out.println(livro1);
    System.out.println(livro2);
    System.out.println(livro3);
    }
}