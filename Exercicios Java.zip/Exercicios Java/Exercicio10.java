//package exercicio10;
//Ex10;
import java.util.Arrays;
import java.util.Scanner;

public class Exercicio10 {
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Insira o tamanho do array(matriz):");
    int tamanho = scanner.nextInt();
        
    int[] array = new int[tamanho];
    System.out.println("Insira os elementos do array:");
    for (int i = 0; i < tamanho; i++) {
            array[i] = scanner.nextInt();
    }
        
        Arrays.sort(array);
        
        System.out.println("Array organizado:");
        for (int num : array) {
            System.out.print(num + " ");
        }
    }
}