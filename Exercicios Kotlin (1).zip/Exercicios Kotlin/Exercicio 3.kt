//Ex3 kt
fun main() {
    print("Insira um número:")
    val numero = readLine()?.toInt() ?: return
    
    when {
        numero > 0 -> println("O número é positivo.")
        numero < 0 -> println("O número é negativo.")
        else -> println("O número é zero.")
    }
}