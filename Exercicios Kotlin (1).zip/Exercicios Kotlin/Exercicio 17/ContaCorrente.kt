//Ex 17A
class ContaCorrente(private var saldo: Double) {

    fun deposito(valor: Double) {
        if (valor > 0) {
            saldo += valor
            println("Depósito de R$$valor realizado. Saldo atual: R$$saldo")
        } else {
            println("Valor de depósito inválido.")
        }
    }

    fun saque(valor: Double) {
        if (valor > 0 && valor <= saldo) {
            saldo -= valor
            println("Saque de R$$valor realizado. Saldo atual: R$$saldo")
        } else {
            println("Valor de saque inválido ou saldo insuficiente.")
        }
    }

    fun transferencia(valor: Double, contaDestino: ContaCorrente) {
        if (valor > 0 && valor <= saldo) {
            saque(valor)
            contaDestino.deposito(valor)
            println("Transferência de R$$valor realizada para a conta de destino.")
        } else {
            println("Valor de transferência inválido ou saldo insuficiente.")
        }
    }
}