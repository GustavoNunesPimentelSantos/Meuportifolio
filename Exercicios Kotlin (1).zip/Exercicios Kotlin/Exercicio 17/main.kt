//Ex 17B
fun main() {
 val conta1 = ContaCorrente(1000.0)
 val conta2 = ContaCorrente(500.0)

    println("Operações na Conta 1:")
    conta1.deposito(250.0) 
    conta1.saque(150.0)   
    conta1.transferencia(172.0, conta2)

    println("\nSaldo atual das duas contas:")
    println("Conta 1: R$${conta1.saldo}")
    println("Conta 2: R$${conta2.saldo}")
}