//Ex 13
open class Pessoa(
    var nome: String,
    var idade: Int
) {
    fun exibirInformacoes() {
        println("Nome: $nome")
        println("Idade: $idade")
    }
}