//Ex 1 Kotlin
fun main() {
    //Aqui considera que valor do dolar é de aproximadamente 5.61.
    val taxaCambio = 5.61
    
    print("Insira o valor em reais: ")
    val valorReais = readLine()?.toDoubleOrNull()
    
    if (valorReais == null) {
        println("Valor inválido. Certifique-se de digitar um número.")
        return
    }
    
    val valorDolares = valorReais / taxaCambio
    
    println("O valor de R$ $valorReais é equivalente a $valorDolares dólares.")
}