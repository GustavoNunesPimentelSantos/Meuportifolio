//Ex 22
fun main() {
 print("Insira uma string: ")
    val input: String? = readLine()

    val comprimento = input?.length
 println("O comprimento da string é: $comprimento")
}