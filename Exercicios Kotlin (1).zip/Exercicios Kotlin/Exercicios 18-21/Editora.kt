//Ex 19
data class Editora(
    val nome: String,
    val endereco: String,
    val cnpj: String
)