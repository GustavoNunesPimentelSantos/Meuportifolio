//Ex 20
public class Livro {
    private String nome;
    private int anoPublicacao;
    private Autor autor;
    private Editora editora;

    public Livro(String nome, int anoPublicacao, Autor autor, Editora editora) {
        this.nome = nome;
        this.anoPublicacao = anoPublicacao;
        this.autor = autor;
        this.editora = editora;
    }

    public String getNome() {
        return nome;
    }

    public int getAnoPublicacao() {
        return anoPublicacao;
    }

    public Autor getAutor() {
        return autor;
    }

    public Editora getEditora() {
        return editora;
    }

    @Override
    public String toString() {
        return "Livro{" +
                "nome='" + nome + '\'' +
                ", anoPublicacao=" + anoPublicacao +
                ", autor=" + autor +
                ", editora=" + editora +
                '}';
    }
}
