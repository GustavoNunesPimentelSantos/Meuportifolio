//Ex 18
data class Autor(
    val nome: String,
    val cpf: String
)