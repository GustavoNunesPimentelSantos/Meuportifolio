//Ex 21
public class Main {
    public static void main(String[] args) {
        Autor autor1 = new Autor("Miguel de Cervantes", "404.421.652-54");
        Autor autor2 = new Autor("Antoine de Saint-Exupéry", "423.557.889-13");
        Autor autor3 = new Autor("J.R.R. Tolkien", "212.343.235-19");

        Editora editora1 = new Editora("La editora", "Rua de Madrid, 441", "21.325.688/0007-69");
        Editora editora2 = new Editora("Geracao Editorial", "Eduardo da Penha, 12", "56.763.635/0014-42");
        Editora editora3 = new Editora("Tolkien", "Rua C, 235", "11.263.980/0001-77");

        Livro livro1 = new Livro("Dom Quixote", 1605, autor1, editora1);
        Livro livro2 = new Livro("O Pequeno Príncipe", 1943, autor2, editora2);
        Livro livro3 = new Livro("O Senhor dos Anéis", 1954, autor3, editora3);

        System.out.println(livro1);
        System.out.println(livro2);
        System.out.println(livro3);
    }
}