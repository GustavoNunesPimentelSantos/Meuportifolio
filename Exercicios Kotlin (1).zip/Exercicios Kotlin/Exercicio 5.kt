//Ex5
fun main() {
    print("Insira um número: ")
    val numero = readLine()?.toIntOrNull() ?: return

    if (numero < 0) {
        println("Números negativos não são palíndromos.")
        return
    }
    val original = numero
    var reverso = 0
    var temp = numero

    while (temp > 0) {
        reverso = reverso * 10 + temp % 10
        temp /= 10
    }

    if (original == reverso) {
        println("O número é um palíndromo.")
    } else {
        println("O número não é um palíndromo.")
    }
}