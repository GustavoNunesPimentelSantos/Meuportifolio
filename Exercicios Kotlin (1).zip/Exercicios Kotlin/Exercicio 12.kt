//Ex 12
class Pessoa(
    private val nome: String,
    private val idade: Int
) {


    fun exibirInformacoes() {
        println("Nome: $nome")
        println("Idade: $idade anos")
    }
}


fun main() {
    val pessoa1 = Pessoa("João", 30)
    
    pessoa1.exibirInformacoes()
    
    val pessoa2 = Pessoa("Maria", 25)
    
    pessoa2.exibirInformacoes()
}