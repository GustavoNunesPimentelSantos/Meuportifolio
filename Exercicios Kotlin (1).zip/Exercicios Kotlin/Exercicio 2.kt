//Ex2 Kotlin
fun main() {
    
    print("Insira o valor inicial: ")
    val inicio = readLine()?.toIntOrNull() ?: 0

    print("Insira o valor final: ")
    val fim = readLine()?.toIntOrNull() ?: 0

    var produto = 1
    for (numero in inicio..fim) {
        produto *= numero
    }
    println("O produto dos números de $inicio até $fim é $produto")
}