//EX11
import kotlin.math.pow
import kotlin.math.sqrt
import java.util.Scanner

fun main() {
    val scanner = Scanner(System.`in`)

    println("Calculadora Científica")
    println("Escolha uma operação:")
    println("1. Exponenciação (base^exponente)")
    println("2. Raiz Quadrada (√valor)")
    
    when (scanner.nextInt()) {
        1 -> {
            println("Insira a base:")
            val base = scanner.nextDouble()
            println("Insira o expoente:")
            val expoente = scanner.nextDouble()
            val resultado = base.pow(expoente)
            println("Resultado: $base ^ $expoente = $resultado")
        }
        2 -> {
            println("Insira o valor para calcular a raiz quadrada:")
            val valor = scanner.nextDouble()
            if (valor < 0) {
                println("Não é possível calcular a raiz quadrada de um número negativo.")
            } else {
                val resultado = sqrt(valor)
                println("Resultado: √$valor = $resultado")
            }
        }
        else -> {
            println("Opção inválida. Por favor, escolha 1 ou 2.")
        }
    }
}