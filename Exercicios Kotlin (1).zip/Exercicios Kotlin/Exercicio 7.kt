//Ex 7
fun main() {

    print("Insira uma string: ")
    val entrada = readLine() ?: ""

    var totalLetras = 0
    var vogais = 0
     var consoantes = 0


    val vogaisSet = setOf('a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U')

    for (char in entrada) {
        if (char.isLetter()) {
            totalLetras++
            if (char in vogaisSet) {
                vogais++
            } else {
                consoantes++
            }
        }
    }

    println("Total de letras: $totalLetras")
    println("Quantidade de vogais: $vogais")
    println("Quantidade de consoantes: $consoantes")
}