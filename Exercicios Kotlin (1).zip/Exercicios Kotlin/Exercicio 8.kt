//Ex 8
fun main() {
    print("Insira um numero: ")
    val numero = readLine()?.toIntOrNull() ?: return println("Valor inválido")

    val numeroInvertido = numero.toString().reversed()

    println("Número invertido: $numeroInvertido")
}