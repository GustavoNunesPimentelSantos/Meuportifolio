//Ex 24
fun main() {
    print("Insira uma string: ")
    val input: String? = readLine()

    val resultado = input ?: "Valor padrão"
    println("Resultado: $resultado")
}