//Ex 9
fun main() {
    print("Insira uma lista de numeros separados por espaço: ")
    val entrada = readLine() ?: ""

    val numeros = entrada.split(" ")
        .mapNotNull { it.toDoubleOrNull() }
        .sorted()

    // Calcula a mediana
    val mediana = if (numeros.isEmpty()) {
        "Lista vazia"
    } else {
        val tamanho = numeros.size
        if (tamanho % 2 == 1) {
        
            numeros[tamanho / 2]} 
        else {
            val meio1 = numeros[tamanho / 2 - 1]
            val meio2 = numeros[tamanho / 2]
            (meio1 + meio2) / 2
        }
    }


    println("A mediana: $mediana")
}