//Ex 25
fun kFuncao(minhaString: String?): String {
    val valorPadrao = "Valor padrão"
    val resultado = minhaString ?: valorPadrao
    println("A string resultante é: $resultado")

    return resultado
}

fun main() {
    val minhaString: String? = null
        kFuncao(minhaString)
}