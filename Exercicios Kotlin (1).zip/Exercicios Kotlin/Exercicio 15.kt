//Ex 15
class Funcionario(
    nome: String,
    idade: Int,
    var salario: Double,
    var cargo: String
) : Pessoa(nome, idade) {
  
    fun exibirInformacoesFuncionario() {
        exibirInformacoes() //Aqui eu solicito o método da superclasse Pessoa.
        println("Salário: $salario")
        println("Cargo: $cargo")
    }
}