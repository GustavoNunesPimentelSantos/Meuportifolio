//Ex 10
fun metrosParaQuilometros(metros: Int): Int {
     
    return metros / 1000
}

fun main() {
   
 print("Insira a distância em metros: ")
    val metros = readLine()?.toIntOrNull() ?: return println("Entrada inválida")

     
    val quilometros = metrosParaQuilometros(metros)

    
 println("$metros metros é igual a $quilometros quilômetros.")
}