//Ex 14
class Aluno(
    nome: String,
    idade: Int,
    var matricula: String,
    var curso: String
) : Pessoa(nome, idade) {

    fun exibirInformacoesAluno() {
        exibirInformacoes() //Aqui eu solicito o método da superclasse Pessoa.
        println("Matrícula: $matricula")
        println("Curso: $curso")
    }
}