//Ex 23
fun main() {
    val lista: List<String?> = listOf("Kotlin", null, "Java", "Swift", null)

    lista.forEach { elemento ->
        elemento?.let {
            println(it)
        }
    }
}