//Ex4 kotlin
fun main() {
    print("Digite um número: ")
    var numero = readLine()?.toIntOrNull() ?: return

    numero = kotlin.math.abs(numero)

    var soma = 0
    var temp = numero

    while (temp > 0) {
        soma += temp % 10
        temp /= 10
    }

    println("A soma dos dígitos é: $soma")
}