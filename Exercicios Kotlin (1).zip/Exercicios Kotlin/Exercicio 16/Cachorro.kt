//Ex 16B
class Cachorro : Animal {
    override fun fazerSom() {
        println("O cachorro late: Au Au!")
    }

    override fun mover() {
        println("O cachorro está correndo.")
    }
}