//Ex 16A
interface Animal {
    fun fazerSom()
    fun mover()
}