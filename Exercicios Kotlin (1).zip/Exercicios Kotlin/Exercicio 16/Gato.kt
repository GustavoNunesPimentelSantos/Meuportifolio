//Ex 16C
class Gato : Animal {
    override fun fazerSom() {
        println("O gato faz: Miau!")
    }

    override fun mover() {
        println("O gato está caminhando.")
    }
}