//Ex6
fun main() {
    print("Insira a primeira string: ")
    val primeiraString = readLine() ?: ""
  
    print("Insira a segunda string: ")
    val segundaString = readLine() ?: ""

    val stringConcatenada = primeiraString + segundaString
    println("A string concatenada é: $stringConcatenada")
}