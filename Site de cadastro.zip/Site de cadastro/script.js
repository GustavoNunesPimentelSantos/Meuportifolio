// Selecionar botões
const loginBtn = document.getElementById('login-btn');
const cadastrarBtn = document.getElementById('cadastrar-btn');

// Containers
const loginContainer = document.getElementById('login-container');
const cadastroContainer = document.getElementById('cadastro-container');
const successMessage = document.getElementById('success-message');

// Login simples
loginBtn.addEventListener('click', () => {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if(username && password) {
        loginContainer.classList.add('hidden');
        cadastroContainer.classList.remove('hidden');
    } else {
        alert('Por favor, preencha usuário e senha.');
    }
});

// Cadastro
cadastrarBtn.addEventListener('click', () => {
    const empresa = document.getElementById('empresa').value;
    const cnpj = document.getElementById('cnpj').value;
    const email = document.getElementById('email').value;
    const telefone = document.getElementById('telefone').value;
    const endereco = document.getElementById('endereco').value;
    const atividade = document.getElementById('atividade').value;

    if(empresa && cnpj && email && telefone && endereco && atividade) {
        successMessage.classList.remove('hidden');

        // Limpar campos
        document.getElementById('empresa').value = '';
        document.getElementById('cnpj').value = '';
        document.getElementById('email').value = '';
        document.getElementById('telefone').value = '';
        document.getElementById('endereco').value = '';
        document.getElementById('atividade').value = '';
    } else {
        alert('Por favor, preencha todos os campos.');
    }
});