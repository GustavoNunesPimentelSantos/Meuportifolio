//package main;
//Criei uma classe filha aluno em que essa estende, ou pega os atributos da superclasse Pessoa.
//Ex17;
public class Aluno extends Pessoa {
    private String matricula;
    private String curso;

    public Aluno(String nome, int idade, String matricula, String curso) {
        super(nome, idade);
        this.matricula = matricula;
        this.curso = curso;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }
    //Sobrecarrego os metodos.
    @Override 
    public void exibirInformacoes() {
    //Busca os elementos da superclasse
    super.exibirInformacoes();
    System.out.println("Matrícula: " + matricula);
    System.out.println("Curso: " + curso);
    }
}