package vendedor;
public class Vendedor {
    //Atributos
    private float vendas;
    private float salario;
    private String nome;
    private int falta;

    // Métodos    
    // Construtor
    public Vendedor(float v, float s, String n, int f) {
        vendas = v;
        salario = s;
        nome = n;
        falta = f;
    }

    // Aqui ficam os Sets e Gets
    public void setVendas(float v) {
        vendas = v;
    }

    public float getVendas() {
        return vendas;
    }

    public void setSalario(float s) {
        salario = s;
    }

    public float getSalario() {
        return salario;
    }

    public void setNome(String n) {
        nome = n;
    }

    public String getNome() {
        return nome;
    }

    public void setFalta(int f) {
        falta = f;
    }

    public int getFalta() {
        return falta;
    }

    // Imprime os dados
    public void imprimirDados() {
        System.out.println("Nome: " + nome);
        System.out.println("Vendas: R$" + vendas);
        System.out.println("Salario: R$" + salario);
        System.out.println("Faltas: " + falta + " dias");
    }

    // O seguinte método faz o calculo das comissoes
    public float calcularComissao() {
        if (vendas >= 1000 && vendas < 2000) {
            return vendas * 0.10f; 
        } else if (vendas >= 2000) {
            return vendas * 0.15f;
        } else {
            return 0; 
        }
    }

    // Calcula as Faltas
    public float descontoFalta() {
        return (salario / 30) * falta;
    }

    // Calcula o Salario final
    public void calcularSalario() {
        float comissao = calcularComissao();
        float desconto = descontoFalta();
        salario = salario + comissao - desconto;
    }
}
