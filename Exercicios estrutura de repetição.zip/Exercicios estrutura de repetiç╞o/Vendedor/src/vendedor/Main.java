package vendedor;
public class Main {
    public static void main(String[] args) {
        // Instanciando um objeto Vendedor
        Vendedor vendedor = new Vendedor(12000, 5293, "bryan", 2);

        // Imprimindo os dados iniciais
        System.out.println("Dados do vendedor:");
        vendedor.imprimirDados();

        // Calculando o salário final
        vendedor.calcularSalario();

        // Imprimindo os dados atualizados
        System.out.println("\nDados do vendedor apos calculo do salario:");
        vendedor.imprimirDados();
    }
}