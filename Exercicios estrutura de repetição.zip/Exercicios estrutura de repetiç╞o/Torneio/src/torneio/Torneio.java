package torneio;

public class Torneio {
    //Atributos
    private String nome;
    private int idade;

    // Construtor
    public Torneio(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    // Métodos get e set para o nome
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    // Métodos get e set para a idade
    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }


    //Averigua as categorias
    public String verificaCategoria() {
        if (idade >= 5 && idade <= 7) {
            return "Infantil";
        } else if (idade >= 8 && idade <= 10) {
            return "Juvenil";
        } else if (idade >= 11 && idade <= 15) {
            return "Adolescente";
        } else if (idade >= 16 && idade <= 30) {
            return "Adulto";
        } else {
            return "Senior"; 
        }
    }

    //Método com a funcao de imprimir os dados
    public void imprimeDados() {
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Categoria: " + verificaCategoria());
    }
}