package torneio;
public class Main {
    public static void main(String[] args) {
        //Faz a criacao dos jogadores
        Torneio jogador1 = new Torneio("Ryan", 35);
        Torneio jogador2 = new Torneio("Julia", 17);

        // Imprime dados dos jogadores
        System.out.println("Dados do jogador 1:");
        jogador1.imprimeDados();
        System.out.println();

        System.out.println("Dados do jogador 2:");
        jogador2.imprimeDados();
    }
}