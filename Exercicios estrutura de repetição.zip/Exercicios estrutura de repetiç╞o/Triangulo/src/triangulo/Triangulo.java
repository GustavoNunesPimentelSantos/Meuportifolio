package triangulo;
class Triangulo {
    //Atributos
    private double base;
    private double altura;

    // Construtor padrao
    public Triangulo() {
        this.base = 0.0;
        this.altura = 0.0;
    }

    // Construtor com parametros
    public Triangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }

    // Métodos de acesso
    public double getBase() {
        return base;
    }

    public void setBase(double base) {
        this.base = base;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double calculaArea() {
        return (base * altura) / 2.0;
    }

    // Imprimir os dados do triangulo
    public void imprimeDados() {
        System.out.println("Base do triangulo: " + base);
        System.out.println("Altura do triangulo: " + altura);
        System.out.println("Area do triangulo: " + calculaArea());
    }
}