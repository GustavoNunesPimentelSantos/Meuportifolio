package triangulo;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        // Cria um objeto com o const padrão.
        Triangulo triangulo1 = new Triangulo();

        // Aqui faz o requerimento ao usuario dos valores das bases e alturas dos respectivos triangulos. 
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o valor da base do triângulo:");
        double base = scanner.nextDouble();
        System.out.println("Digite o valor da altura do triângulo:");
        double altura = scanner.nextDouble();

        // Aqui configura os dados da base e altura.
        triangulo1.setBase(base);
        triangulo1.setAltura(altura);

        // Imprimindo os dados e a área do triângulo
        System.out.println("Triângulo 1:");
        triangulo1.imprimeDados();

        // Criando um objeto usando o construtor com parâmetros
        Triangulo triangulo2 = new Triangulo(5.0, 3.0);

        // Imprime os dados do segundo triangulo
         System.out.println("\nTriangulo 2:");
        triangulo2.imprimeDados();

        scanner.close();
    }
}