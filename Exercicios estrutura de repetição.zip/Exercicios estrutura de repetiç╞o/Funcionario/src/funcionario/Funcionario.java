package funcionario;
public class Funcionario {
    private int cracha;
    private float salario;
    private String cargo;

    // Const sem parâmetros
    public Funcionario() {
        this.cargo = "assistente";
    }

    // Const com parâmetros
    public Funcionario(int c, float s, String car) {
        this.cracha = c;
        this.salario = s;
        this.cargo = car;
    }

    // Métodos de acesso

    public void setCracha(int c) {
        this.cracha = c;
    }

    public int getCracha() {
        return this.cracha;
    }

    public void setSalario(float s) {
        this.salario = s;
    }

    public float getSalario() {
        return this.salario;
    }

    public void setCargo(String car) {
        this.cargo = car;
    }

    public String getCargo() {
        return this.cargo;
    }

    public void calculaAumento(float porcentagem) {
        float aumento = (this.salario * porcentagem) / 100;
        this.salario += aumento;
    }

    public void calculaAumento(int tempo) {
        float aumento = (tempo * 150.0f);
        this.salario += aumento;
    }
}