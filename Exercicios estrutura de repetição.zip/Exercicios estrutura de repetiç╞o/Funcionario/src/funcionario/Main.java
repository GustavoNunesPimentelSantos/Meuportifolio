package funcionario;
public class Main {
        public static void main(String[] args) {

        Funcionario funcionario1 = new Funcionario();
        System.out.println("Funcionario 1:");
        System.out.println("Cargo: " + funcionario1.getCargo());

        Funcionario funcionario2 = new Funcionario(321, 9820.0f, "Analista");
        System.out.println("\nFuncionario 2:");
        System.out.println("Cracha: " + funcionario2.getCracha()); 
        System.out.println("Salário: " + funcionario2.getSalario()); 
        System.out.println("Cargo: " + funcionario2.getCargo()); 

        funcionario2.calculaAumento(10);
        System.out.println("\nNovo salario do Funcionario 2 apos aumento de 10%: " + funcionario2.getSalario()); 

        funcionario2.calculaAumento(3);
        System.out.println("Novo salário do Funcionario 2 após 3 anos de trabalho: " + funcionario2.getSalario());
    }
}
