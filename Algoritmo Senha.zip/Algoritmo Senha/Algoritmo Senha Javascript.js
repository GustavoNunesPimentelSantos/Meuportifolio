function SimplePassword(str) {
  // __define-ocg__: Validação da senha conforme os requisitos do desafio da senha.
  let varOcg = str.toLowerCase();

  if (
    str.length > 7 &&
    str.length < 31 &&
    /[A-Z]/.test(str) &&
    /\d/.test(str) &&
    /[^A-Za-z0-9]/.test(str) &&
    !varOcg.includes("password")
  ) {
    return true;
  }

  return false;
}

// Keep this function call here
console.log(SimplePassword(readline()));